package com.naba.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import java.net.URLEncoder

class ActionExecutor(private val ctx: Context) {

    private fun say(a: String) = NabaState.update(action = a)
    private fun done(l: Lang) = tr(l, "Done.", "हो गया।", "হ'ল।")
    private fun fail(l: Lang) = tr(l, "Sorry, I couldn't do that.", "माफ़ कीजिए, यह नहीं हो पाया।", "দুঃখিত, এইটো কৰিব নোৱাৰিলোঁ।")
    private fun needA11y(l: Lang) = tr(l, "Please turn on my Accessibility permission in the Naba app.",
        "कृपया Naba ऐप में मेरी Accessibility अनुमति चालू करें।", "অনুগ্ৰহ কৰি Naba এপত মোৰ Accessibility অনুমতি অন কৰক।")

    /** Activities are launched from the accessibility service when it is on: it owns a visible window, so Android allows it from the background. */
    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (NabaAccessibilityService.instance ?: ctx).startActivity(i); true
    } catch (e: Exception) { false }

    private fun a11y(l: Lang, act: String, f: (NabaAccessibilityService) -> Boolean): String {
        say(act)
        val s = NabaAccessibilityService.instance ?: return needA11y(l)
        return if (f(s)) done(l) else fail(l)
    }

    fun execute(c: Command, l: Lang): String = when (c) {
        Command.Home -> a11y(l, "Going Home") { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }
        Command.Back -> a11y(l, "Going Back") { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }
        Command.Recents -> a11y(l, "Opening Recent apps") { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        Command.ScrollDown -> a11y(l, "Scrolling down") { it.scroll(true) }
        Command.ScrollUp -> a11y(l, "Scrolling up") { it.scroll(false) }
        is Command.Tap -> a11y(l, "Tapping “${c.label}”") { it.tap(c.label) }
        is Command.OpenApp -> {
            say("Opening ${c.label}")
            val i = if (c.pkg.isBlank()) null else ctx.packageManager.getLaunchIntentForPackage(c.pkg)
            if (i != null && launch(i)) tr(l, "Opening ${c.label}", "${c.label} खोल रही हूँ", "${c.label} খুলিছোঁ")
            else tr(l, "I couldn't find ${c.label}.", "मुझे ${c.label} नहीं मिला।", "${c.label} বিচাৰি নাপালোঁ।")
        }
        Command.Camera -> { say("Opening Camera"); if (launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) done(l) else fail(l) }
        Command.OpenSettings -> { say("Opening Settings"); if (launch(Intent(Settings.ACTION_SETTINGS))) done(l) else fail(l) }
        Command.Browser -> { say("Opening browser"); if (launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))) done(l) else fail(l) }
        is Command.Search -> {
            say("Searching “${c.query}”")
            val q = URLEncoder.encode(c.query, "UTF-8")
            val url = if (c.youtube) "https://www.youtube.com/results?search_query=$q" else "https://www.google.com/search?q=$q"
            if (launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) tr(l, "Here you go.", "ये लीजिए।", "এইয়া লওক।") else fail(l)
        }
        is Command.Torch -> torch(c.on, l)
        is Command.Volume -> volume(c.dir, l)
        Command.Notifications -> notifications(l)
        is Command.Call -> call(c.target, l)
        is Command.Message -> message(c, l)
        Command.Cancel, Command.Unknown -> fail(l)
    }

    private fun torch(on: Boolean, l: Lang): String = try {
        say(if (on) "Torch on" else "Torch off")
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on); done(l)
    } catch (e: Exception) { fail(l) }

    private fun volume(dir: Int, l: Lang): String {
        say(when (dir) { 1 -> "Volume up"; -1 -> "Volume down"; else -> "Mute" })
        val am = ctx.getSystemService(AudioManager::class.java)
        val d = when (dir) { 1 -> AudioManager.ADJUST_RAISE; -1 -> AudioManager.ADJUST_LOWER; else -> AudioManager.ADJUST_MUTE }
        repeat(if (dir == 0) 1 else 2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI) }
        return done(l)
    }

    private fun notifications(l: Lang): String {
        say("Reading notifications")
        val list = NabaNotificationListener.recent()
            ?: return tr(l, "Please allow notification access in the Naba app first.", "कृपया पहले Naba ऐप में नोटिफिकेशन एक्सेस दें।", "অনুগ্ৰহ কৰি প্ৰথমে Naba এপত জাননী অনুমতি দিয়ক।")
        if (list.isEmpty()) return tr(l, "You have no new notifications.", "कोई नई नोटिफिकेशन नहीं है।", "কোনো নতুন জাননী নাই।")
        return list.joinToString(". ")
    }

    private fun numberFor(who: String): String? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.length >= 7) return digits
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.NUMBER), "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)
            ?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun noContact(who: String, l: Lang) = tr(l,
        "I couldn't find $who. Please allow Contacts permission, or say the number.",
        "मुझे $who नहीं मिला। कृपया Contacts अनुमति दें, या नंबर बोलिए।",
        "$who বিচাৰি নাপালোঁ। অনুগ্ৰহ কৰি Contacts অনুমতি দিয়ক, বা নম্বৰ কওক।")

    fun call(target: String, l: Lang): String {
        val num = numberFor(target) ?: return noContact(target, l)
        say("Calling $target")
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val ok = launch(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
        return if (ok) tr(l, "Calling $target", "$target को कॉल कर रही हूँ", "$target ক কল কৰিছোঁ") else fail(l)
    }

    /** Opens the message already written for you; you press Send yourself. */
    fun message(c: Command.Message, l: Lang): String {
        val num = numberFor(c.recipient) ?: return noContact(c.recipient, l)
        say("Preparing message to ${c.recipient}")
        val i = if (c.whatsapp) {
            var n = num.filter { it.isDigit() }; if (n.length == 10) n = "91$n"
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=${Uri.encode(c.body)}"))
        } else Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", c.body)
        return if (launch(i)) tr(l, "I've written the message. Please tap Send.", "मैसेज लिख दिया है। कृपया भेजें दबाइए।", "বাৰ্তা লিখি দিলোঁ। অনুগ্ৰহ কৰি Send টিপক।") else fail(l)
    }
}
