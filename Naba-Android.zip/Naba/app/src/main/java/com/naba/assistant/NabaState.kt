package com.naba.assistant

import android.os.Handler
import android.os.Looper

/** Tiny in-memory state shared by the service, the app screen and the floating bubble. Nothing is persisted. */
object NabaState {
    enum class Mode { OFF, WAKE, LISTENING, THINKING, SPEAKING }

    var mode = Mode.OFF; private set
    var live = ""; private set
    var action = ""; private set

    private val main = Handler(Looper.getMainLooper())
    private val listeners = mutableSetOf<() -> Unit>()

    fun listen(l: () -> Unit) { listeners += l }
    fun unlisten(l: () -> Unit) { listeners -= l }

    fun update(mode: Mode? = null, live: String? = null, action: String? = null) {
        main.post {
            mode?.let { this.mode = it }
            live?.let { this.live = it }
            action?.let { this.action = it }
            listeners.toList().forEach { it() }
        }
    }
}
