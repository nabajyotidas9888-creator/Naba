package com.naba.assistant

enum class Lang { EN, HI, AS }

fun tr(l: Lang, en: String, hi: String, asm: String) = when (l) { Lang.EN -> en; Lang.HI -> hi; Lang.AS -> asm }

object LangDetect {
    private val asWords = setOf("kor", "kora", "kori", "khuli", "loi", "moi", "mor", "kowa", "koribo", "lagibo", "kom", "bondho", "dibi", "pathiya", "pathao")
    private val hiWords = setOf("karo", "kholo", "kar", "dikhao", "mujhe", "mera", "hai", "kya", "nahi", "band", "badhao", "batao", "bhejo", "wapas", "niche", "upar", "kam", "jyada", "zyada", "haan", "likho", "bajao")

    fun detect(text: String): Lang {
        var asC = 0; var hiC = 0
        text.forEach { if (it.code in 0x0980..0x09FF) asC++ else if (it.code in 0x0900..0x097F) hiC++ }
        if (asC > hiC) return Lang.AS
        if (hiC > asC) return Lang.HI
        val w = text.lowercase().split(Regex("[^a-z]+")).toSet()
        val a = w.count { it in asWords }; val h = w.count { it in hiWords }
        return when { a > h -> Lang.AS; h > 0 -> Lang.HI; else -> Lang.EN }
    }
}

object YesNo {
    private val no = setOf("no", "nope", "nahi", "nahin", "na", "cancel", "dont", "नहीं", "नही", "নহয়", "নাই", "না")
    private val yes = setOf("yes", "yeah", "yep", "yup", "ok", "okay", "sure", "confirm", "proceed", "haan", "han", "ha", "haa", "ji", "theek", "thik", "हाँ", "हां", "हा", "जी", "ठीक", "हो", "হয়", "হ্যাঁ", "ঠিক")
    fun yes(t: String): Boolean {
        val w = t.lowercase().split(Regex("[\\s,.?!।']+")).toSet()
        return w.none { it in no } && w.any { it in yes }
    }
}
