package com.naba.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("naba", MODE_PRIVATE) }
    private val ui: () -> Unit = { render() }
    private var pulse: ObjectAnimator? = null

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        render()
        if (hasMic() && prefs.getBoolean("wake", true)) startNaba(NabaService.ACTION_START)
    }

    private fun <T : View> v(id: Int) = findViewById<T>(id)
    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = granted(Manifest.permission.RECORD_AUDIO)
    private fun a11yOn() = NabaAccessibilityService.instance != null
    private fun notifOn() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)

        v<ImageView>(R.id.micButton).setOnClickListener { if (hasMic()) startNaba(NabaService.ACTION_LISTEN) else askMic() }

        val sw = v<SwitchCompat>(R.id.swWake)
        sw.isChecked = prefs.getBoolean("wake", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("wake", on).apply()
            if (on && hasMic()) startNaba(NabaService.ACTION_START)
            if (!on) startService(Intent(this, NabaService::class.java).setAction(NabaService.ACTION_STOP))
        }

        val rg = v<RadioGroup>(R.id.rgLang)
        rg.check(when (prefs.getString("lang", "auto")) { "as" -> R.id.rbAs; "hi" -> R.id.rbHi; "en" -> R.id.rbEn; else -> R.id.rbAuto })
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putString("lang", when (id) { R.id.rbAs -> "as"; R.id.rbHi -> "hi"; R.id.rbEn -> "en"; else -> "auto" }).apply()
        }

        v<Button>(R.id.btnMic).setOnClickListener {
            explain("Microphone", "Naba needs the microphone to hear “Hi Naba” and your commands. The wake phrase is detected on your phone, offline. Nothing is recorded or saved.") { askMic() }
        }
        v<Button>(R.id.btnA11y).setOnClickListener {
            explain("Accessibility", "Naba uses Android's Accessibility Service only to press Home/Back, scroll and tap buttons when you ask. It does not read, record or store what is on your screen. Find “Naba” in the list and turn it on.") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        v<Button>(R.id.btnNotif).setOnClickListener {
            explain("Notification access", "Optional. Lets Naba read your notifications aloud when you ask “read my notifications”. They are never stored or sent anywhere.") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        v<Button>(R.id.btnContacts).setOnClickListener {
            explain("Contacts & Phone", "Optional. Lets Naba find a contact's number and place a call. Naba always asks you to confirm before calling or messaging.") {
                perms.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
            }
        }
        v<Button>(R.id.btnVoice).setOnClickListener {
            startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    override fun onStart() { super.onStart(); NabaState.listen(ui); render() }
    override fun onStop() { NabaState.unlisten(ui); super.onStop() }

    override fun onResume() {
        super.onResume()
        render()
        // The app is visible now, so Android lets us (re)start the microphone service, e.g. after a reboot.
        if (hasMic() && prefs.getBoolean("wake", true) && !NabaService.running) startNaba(NabaService.ACTION_START)
    }

    private fun askMic() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }

    private fun startNaba(action: String) {
        ContextCompat.startForegroundService(this, Intent(this, NabaService::class.java).setAction(action))
    }

    private fun explain(title: String, msg: String, go: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("Continue") { _, _ -> go() }.setNegativeButton("Not now", null).show()
    }

    private fun render() {
        val s = NabaState
        v<TextView>(R.id.tvStatus).text = when (s.mode) {
            NabaState.Mode.OFF -> "Naba is resting"
            NabaState.Mode.WAKE -> "Listening for “Hi Naba”"
            NabaState.Mode.LISTENING -> "Listening…"
            NabaState.Mode.THINKING -> "Thinking…"
            NabaState.Mode.SPEAKING -> "Speaking…"
        }
        v<TextView>(R.id.tvLive).text = s.live
        v<TextView>(R.id.tvAction).text = s.action

        val mic = v<ImageView>(R.id.micButton)
        if (s.mode == NabaState.Mode.LISTENING) {
            if (pulse == null) pulse = ObjectAnimator.ofPropertyValuesHolder(mic,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.2f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.2f)).apply {
                duration = 600; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start()
            }
        } else { pulse?.cancel(); pulse = null; mic.scaleX = 1f; mic.scaleY = 1f }

        v<Button>(R.id.btnMic).text = if (hasMic()) "Microphone ✓" else "Allow microphone"
        v<Button>(R.id.btnA11y).text = if (a11yOn()) "Accessibility ✓" else "Turn on Accessibility"
        v<Button>(R.id.btnNotif).text = if (notifOn()) "Notification access ✓" else "Allow notification access"
        v<Button>(R.id.btnContacts).text = if (granted(Manifest.permission.READ_CONTACTS)) "Contacts & Phone ✓" else "Allow contacts & phone"
    }
}
