package com.naba.assistant

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Text-to-speech wrapper: higher pitch for a soft, cute tone; uses the phone's installed Indian voices. */
class NabaVoice(ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private val callbacks = HashMap<String, () -> Unit>()
    private val emoji = Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}]")

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.apply {
                setPitch(1.3f)
                setSpeechRate(0.95f)
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { fire(id) }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { fire(id) }
                })
            }
        }
    }

    private fun fire(id: String?) { callbacks.remove(id)?.let { main.post(it) } }

    private fun locale(t: TextToSpeech, l: Lang): Locale {
        val options = when (l) {
            Lang.HI -> listOf(Locale("hi", "IN"))
            Lang.AS -> listOf(Locale("as", "IN"), Locale("bn", "IN"))   // Assamese voice if installed, else Bengali
            Lang.EN -> listOf(Locale("en", "IN"))
        }
        return options.firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE } ?: Locale("en", "IN")
    }

    fun speak(text: String, lang: Lang, done: () -> Unit) {
        val t = tts
        if (t == null || !ready) { main.post(done); return }
        t.language = locale(t, lang)
        val id = UUID.randomUUID().toString()
        callbacks[id] = done
        t.speak(text.replace(emoji, "").trim(), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
