package com.naba.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.abs

/** Performs Home/Back/Recents/scroll/tap on request, and hosts the floating mic bubble. It never reads or stores screen content. */
class NabaAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: NabaAccessibilityService? = null }

    private lateinit var wm: WindowManager
    private var overlay: LinearLayout? = null
    private lateinit var bubble: ImageView
    private lateinit var bubbleText: TextView
    private val stateListener: () -> Unit = { render() }

    override fun onServiceConnected() {
        instance = this
        addOverlay()
        NabaState.listen(stateListener)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        NabaState.unlisten(stateListener)
        overlay?.let { runCatching { wm.removeView(it) } }
        return super.onUnbind(intent)
    }

    // ---- actions -------------------------------------------------------------------------------
    fun global(action: Int) = performGlobalAction(action)

    fun scroll(forward: Boolean): Boolean {
        val n = findScrollable(rootInActiveWindow) ?: return false
        return n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    fun tap(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (node in root.findAccessibilityNodeInfosByText(label)) {
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    // ---- floating bubble -----------------------------------------------------------------------
    private fun addOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dp = resources.displayMetrics.density
        bubbleText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; maxWidth = (240 * dp).toInt()
            setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt())
            background = GradientDrawable().apply { cornerRadius = 16 * dp; setColor(0xCC333333.toInt()) }
            visibility = View.GONE
        }
        bubble = ImageView(this).apply { setImageResource(R.drawable.ic_naba); contentDescription = "Naba" }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.END
            addView(bubbleText)
            addView(bubble, LinearLayout.LayoutParams((56 * dp).toInt(), (56 * dp).toInt()))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * dp).toInt(); y = (260 * dp).toInt() }

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(overlay, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onBubbleTap()
                }
                return true
            }
        })
        wm.addView(overlay, lp)
        render()
    }

    private fun onBubbleTap() {
        ContextCompat.startForegroundService(this, Intent(this, NabaService::class.java).setAction(NabaService.ACTION_LISTEN))
    }

    private fun render() {
        val s = NabaState
        val active = s.mode == NabaState.Mode.LISTENING || s.mode == NabaState.Mode.THINKING || s.mode == NabaState.Mode.SPEAKING
        val lines = listOfNotNull(s.live.takeIf { it.isNotBlank() }?.let { "🎤 $it" }, s.action.takeIf { it.isNotBlank() }?.let { "✨ $it" })
        bubbleText.text = lines.joinToString("\n")
        bubbleText.visibility = if (active && lines.isNotEmpty()) View.VISIBLE else View.GONE
        val scale = if (s.mode == NabaState.Mode.LISTENING) 1.25f else 1f
        bubble.animate().scaleX(scale).scaleY(scale).setDuration(250).start()
        bubble.alpha = if (s.mode == NabaState.Mode.OFF) 0.6f else 1f
    }
}
