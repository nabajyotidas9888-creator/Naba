package com.naba.assistant

import android.content.Context
import android.content.Intent

sealed class Command {
    object Home : Command(); object Back : Command(); object Recents : Command()
    object ScrollUp : Command(); object ScrollDown : Command()
    object Camera : Command(); object OpenSettings : Command(); object Browser : Command()
    object Notifications : Command(); object Cancel : Command(); object Unknown : Command()
    data class OpenApp(val label: String, val pkg: String) : Command()
    data class Torch(val on: Boolean) : Command()
    data class Volume(val dir: Int) : Command()           // +1 up, -1 down, 0 mute
    data class Search(val query: String, val youtube: Boolean) : Command()
    data class Call(val target: String) : Command()
    data class Message(val recipient: String, val body: String, val whatsapp: Boolean) : Command()
    data class Tap(val label: String) : Command()
}

/** Keyword parser for Assamese / Hindi / English (native script + romanized) and mixes of them. */
object CommandParser {
    private val ALIASES = mapOf(
        "यूट्यूब" to "youtube", "ইউটিউব" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "वॉट्सऐप" to "whatsapp", "হোৱাটছএপ" to "whatsapp", "হোৱাটচএপ" to "whatsapp", "ৱাটছএপ" to "whatsapp",
        "क्रोम" to "chrome", "ক্ৰোম" to "chrome", "फेसबुक" to "facebook", "ফেচবুক" to "facebook",
        "इंस्टाग्राम" to "instagram", "ইনষ্টাগ্ৰাম" to "instagram", "जीमेल" to "gmail", "জীমেইল" to "gmail",
        "गूगल" to "google", "গুগল" to "google", "टेलीग्राम" to "telegram", "मैप्स" to "maps", "ম্যাপ" to "maps"
    )
    private val FILLER = setOf(
        "please", "plz", "kor", "kora", "koro", "kori", "karo", "kar", "kare", "do", "de", "dena", "diya", "dijiye", "dio", "dia",
        "koribo", "ko", "ka", "ki", "loi", "me", "mein", "mai", "moi", "a", "the", "for", "on", "in", "to", "now", "jaldi",
        "ekhon", "aru", "and", "hi", "hii", "hey", "ok", "okay", "na", "t", "from", "about", "ja", "jao", "जा", "करो", "कर", "दो", "लो", "কৰক", "কৰা", "দিয়া"
    )
    private val OPEN = setOf("open", "launch", "start", "kholo", "khol", "khuli", "kholibo", "खोलो", "खोल", "खुलि", "খোলক", "খোল", "খুলি", "চলাও", "चलाओ")
    private val SEARCH = setOf("search", "khoj", "khuj", "find", "dhundh", "dhoondh", "खोज", "ढूंढ", "ढूँढ", "সন্ধান", "বিচাৰ")
    private val PLAY = setOf("play", "bajao", "chalao", "बजाओ", "চলোৱা")
    private val TAP = setOf("tap", "click", "press", "daba", "dabao", "दबाओ", "दबा", "क्लिक", "টিপক", "টিপা")
    private val CALL = setOf("call", "dial", "कॉल", "कल", "কল", "ফোন", "फोन", "phone", "number")
    private val SENSITIVE = listOf("delete", "remove", "uninstall", "pay", "send", "transfer", "buy", "order", "purchase", "confirm", "submit",
        "डिलीट", "हटा", "भेज", "भुगतान", "मिटा", "মচি", "পঠিয়া", "পেমেন্ট", "ডিলিট")

    fun isSensitive(c: Command.Tap) = SENSITIVE.any { c.label.lowercase().contains(it) }

    fun loadApps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }.distinct()
    }

    fun parse(raw: String, apps: List<Pair<String, String>>): Command {
        var t = raw.lowercase().replace(Regex("['’]t\\b"), "")
        for (n in listOf("naba", "नाबा", "নাবা")) t = t.replace(n, " ")
        ALIASES.forEach { (k, v) -> t = t.replace(k, v) }
        t = t.trim()
        val tokens = t.split(Regex("[\\s,.?!।]+")).filter { it.isNotBlank() }
        fun has(vararg w: String) = w.any { if (it.length <= 3 && it.all { c -> c.code < 128 }) it in tokens else t.contains(it) }
        fun strip(extra: Set<String>) = tokens.filter { it !in FILLER && it !in extra }.joinToString(" ")

        if (has("cancel", "never mind", "nevermind", "stop", "रुको", "छोड़ो", "বাদ দিয়া", "থাক", "rukho", "thak")) return Command.Cancel
        if (has("home", "होम", "হোম")) return Command.Home
        if (has("back", "peeche", "piche", "wapas", "वापस", "पीछे", "পাছলৈ", "পিছলৈ")) return Command.Back
        if (has("recent", "recents", "overview", "रीसेंट", "ৰিচেণ্ট")) return Command.Recents
        if (has("scroll", "स्क्रॉल", "স্ক্ৰল", "niche", "नीचे", "তললৈ", "upar", "ऊपर", "ওপৰলৈ"))
            return if (has("up", "upar", "ऊपर", "ওপৰলৈ")) Command.ScrollUp else Command.ScrollDown
        if (has("torch", "flash", "flashlight", "टॉर्च", "টৰ্চ", "फ्लैश"))
            return Command.Torch(!has("off", "band", "bandh", "bondho", "बंद", "বন্ধ"))
        if (has("volume", "awaj", "awaz", "आवाज", "आवाज़", "আৱাজ", "ভলিউম", "वॉल्यूम"))
            return Command.Volume(when {
                has("mute", "silent", "म्यूट", "চুপ") -> 0
                has("kom", "kam", "down", "low", "कम", "কম", "decrease", "lower", "घटा", "ghata") -> -1
                else -> 1
            })
        if (has("camera", "कैमरा", "কেমেৰা", "ক্যামেৰা")) return Command.Camera
        if (has("settings", "setting", "सेटिंग", "ছেটিং")) return Command.OpenSettings
        if (has("notification", "notifications", "नोटिफ", "জাননী")) return Command.Notifications
        if (has("call", "dial", "कॉल", "কল", "ফোন", "फोन")) return Command.Call(strip(CALL))

        if (has("message", "msg", "sms", "text", "मैसेज", "संदेश", "বাৰ্তা", "মেছেজ", "মেচেজ")) {
            val body = Regex("""(?:\bsaying\b|\bsay\b|\bthat\b|\blikho\b|\blikh\b|\bbolo\b|\bkowa\b|कहो|लिखो|বুলি|লিখক)\s+(.+)$""").find(t)?.groupValues?.get(1) ?: ""
            val rec = (Regex("""(\S+)\s+(?:ko|loi|को|লৈ)(?:\s|$)""").find(t) ?: Regex("""\bto\s+(\S+)""").find(t))?.groupValues?.get(1) ?: ""
            return Command.Message(rec, body, t.contains("whatsapp"))
        }

        val yt = has("youtube")
        if (has(*SEARCH.toTypedArray()) || (yt && has(*PLAY.toTypedArray()))) {
            val q = strip(SEARCH + PLAY + setOf("youtube", "google", "पर", "में", "ত"))
            return Command.Search(q, yt)
        }
        if (has("delete", "remove", "uninstall", "मिटा", "डिलीट", "हटा", "মচি", "ডিলিট")) return Command.Tap("Delete")
        if (has("browser", "ब्राउज़र", "ব্ৰাউজাৰ", "google", "গুগল")) return Command.Browser
        if (has(*TAP.toTypedArray())) {
            val label = strip(TAP)
            return if (label.isBlank()) Command.Unknown else Command.Tap(label)
        }

        val hit = apps.filter { (label, _) -> label.length >= 3 && Regex("\\b" + Regex.escape(label) + "\\b").containsMatchIn(t) }
            .maxByOrNull { it.first.length }
        if (hit != null) return Command.OpenApp(hit.first, hit.second)
        if (has(*OPEN.toTypedArray())) {
            val name = strip(OPEN)
            if (name.isBlank()) return Command.Unknown
            val f = apps.firstOrNull { it.first.contains(name) }
            return Command.OpenApp(f?.first ?: name, f?.second ?: "")
        }
        return Command.Unknown
    }
}
