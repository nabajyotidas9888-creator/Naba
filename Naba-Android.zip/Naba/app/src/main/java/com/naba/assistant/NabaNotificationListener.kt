package com.naba.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService

/** Only reads currently-visible notifications when you ask Naba to. Nothing is stored. */
class NabaNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: NabaNotificationListener? = null
        fun recent(): List<String>? {
            val s = instance ?: return null
            return s.activeNotifications.filter { !it.isOngoing }.take(5).map {
                val app = runCatching { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(it.packageName, 0)).toString() }.getOrDefault(it.packageName)
                val e = it.notification.extras
                "$app: ${e.getCharSequence(Notification.EXTRA_TITLE) ?: ""} ${e.getCharSequence(Notification.EXTRA_TEXT) ?: ""}".trim()
            }
        }
    }
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }
}
