package com.naba.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File

/**
 * Foreground service that (1) listens offline for "Hi Naba" with Vosk, then
 * (2) hands the mic to Android's SpeechRecognizer for the actual command, (3) acts, (4) speaks back.
 */
class NabaService : Service() {
    companion object {
        const val ACTION_START = "naba.START"
        const val ACTION_LISTEN = "naba.LISTEN"
        const val ACTION_STOP = "naba.STOP"
        private const val CHANNEL = "naba_listening"
        private const val MODEL_ASSET = "model-en-in"
        @Volatile var running = false

        private val WAKE = Regex("\\b(hi+|hey|hello)\\b.*\\b(na+b+h?a+h?|nava|nabha|nubba|nabah)\\b")
        private val GREETINGS = listOf(
            "Hii 😊, moi Naba. Kowa, ki koribo lage?",
            "Hii, I’m Naba. How can I help you?",
            "Hii, Naba yatei asu. Kowa 😊"
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("naba", MODE_PRIVATE) }
    private var model: Model? = null
    private var grammar: String? = null
    private var wakeSvc: SpeechService? = null
    private var asr: SpeechRecognizer? = null
    private lateinit var voice: NabaVoice
    private lateinit var exec: ActionExecutor
    private var busy = false
    private var followUp: ((String, Lang) -> Unit)? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        voice = NabaVoice(this)
        exec = ActionExecutor(this)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (!goForeground()) return START_NOT_STICKY
        when (i?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_LISTEN -> if (!busy) { busy = true; stopWake(); beginListening() }
            else -> if (!busy) startWake()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        stopWake(); asr?.destroy(); voice.shutdown(); model?.close()
        NabaState.update(NabaState.Mode.OFF, "", "")
        super.onDestroy()
    }

    private fun goForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Naba listening", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, NabaService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_naba)
            .setContentTitle("Naba").setContentText("Listening for “Hi Naba”")
            .setContentIntent(open).addAction(0, "Turn off", stop).setOngoing(true).build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
            true
        } catch (e: Exception) { stopSelf(); false }   // Android 14+ refuses mic services started from the background
    }

    // ---- wake word (offline) --------------------------------------------------------------------
    private fun loadModel(done: () -> Unit) {
        if (model != null) return done()
        if (assets.list(MODEL_ASSET).isNullOrEmpty()) {
            NabaState.update(NabaState.Mode.OFF, "", "Wake-word model missing (see README). You can still tap the mic."); return
        }
        Thread {
            try {
                val dir = File(filesDir, "vosk-model")
                if (!File(dir, "am").exists()) copyAssets(MODEL_ASSET, dir)
                val vocab = File(dir, "graph/words.txt").takeIf { it.exists() }
                    ?.useLines { s -> s.map { it.substringBefore(' ') }.toHashSet() } ?: emptySet()
                val names = listOf("naba", "nabha", "nava", "nabah", "nubba").filter { it in vocab }
                grammar = if (names.isEmpty()) null else {
                    val heads = listOf("hi", "hey", "hi i am", "hi me", "hi i'm")
                    JSONArray(heads.flatMap { h -> names.map { "$h $it" } } + "[unk]").toString()
                }
                model = Model(dir.absolutePath)
                main.post(done)
            } catch (e: Exception) {
                NabaState.update(NabaState.Mode.OFF, "", "Couldn't load wake model: ${e.message}")
            }
        }.start()
    }

    private fun copyAssets(path: String, out: File) {
        val kids = assets.list(path) ?: return
        if (kids.isEmpty()) {
            out.parentFile?.mkdirs()
            assets.open(path).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        } else {
            out.mkdirs()
            kids.forEach { copyAssets("$path/$it", File(out, it)) }
        }
    }

    private fun startWake() {
        if (!prefs.getBoolean("wake", true)) { NabaState.update(NabaState.Mode.OFF, "", "Wake word is off — tap the mic"); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            NabaState.update(NabaState.Mode.OFF, "", "Microphone permission needed"); return
        }
        loadModel {
            if (busy) return@loadModel
            stopWake()
            try {
                val m = model!!
                val rec = grammar?.let { Recognizer(m, 16000f, it) } ?: Recognizer(m, 16000f)
                wakeSvc = SpeechService(rec, 16000f).also { it.startListening(wakeListener) }
                NabaState.update(NabaState.Mode.WAKE, "", "Say “Hi Naba”")
            } catch (e: Exception) {
                NabaState.update(NabaState.Mode.OFF, "", "Mic busy, retrying…")
                main.postDelayed({ if (!busy) startWake() }, 3000)
            }
        }
    }

    private fun stopWake() { wakeSvc?.stop(); wakeSvc?.shutdown(); wakeSvc = null }

    private val wakeListener = object : org.vosk.android.RecognitionListener {
        override fun onPartialResult(h: String?) = check(h)
        override fun onResult(h: String?) = check(h)
        override fun onFinalResult(h: String?) {}
        override fun onError(e: Exception?) { main.post { if (!busy) startWake() } }
        override fun onTimeout() {}
        private fun check(json: String?) {
            if (json == null) return
            val o = JSONObject(json)
            val t = o.optString("partial").ifEmpty { o.optString("text") }
            if (WAKE.containsMatchIn(t)) main.post { onWake() }
        }
    }

    private fun onWake() {
        if (busy) return
        busy = true
        stopWake()
        NabaState.update(NabaState.Mode.SPEAKING, "", "Hello!")
        voice.speak(GREETINGS.random(), Lang.EN) { beginListening() }
    }

    // ---- command listening ---------------------------------------------------------------------
    private fun prefLang() = when (prefs.getString("lang", "auto")) { "as" -> Lang.AS; "hi" -> Lang.HI; else -> Lang.EN }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Speech recognition isn't available on this phone.", Lang.EN); return
        }
        asr?.destroy()
        asr = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(cmdListener) }
        val tag = when (prefs.getString("lang", "auto")) { "as" -> "as-IN"; "hi" -> "hi-IN"; else -> "en-IN" }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            if (Build.VERSION.SDK_INT >= 33 && prefs.getString("lang", "auto") == "auto") {
                putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, arrayListOf("as-IN", "hi-IN", "en-IN"))
            }
        }
        asr?.startListening(i)
    }

    private val cmdListener = object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { NabaState.update(NabaState.Mode.LISTENING, "", "Listening…") }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onPartialResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { NabaState.update(live = it) }
        }
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) noInput() else handle(t)
        }
        override fun onError(code: Int) { noInput() }
    }

    private fun noInput() {
        val l = prefLang()
        reply(tr(l, "Sorry, I didn't catch that.", "माफ़ कीजिए, मैं सुन नहीं पाई।", "দুঃখিত, শুনিব নোৱাৰিলোঁ।"), l)
    }

    // ---- understanding + acting ----------------------------------------------------------------
    private fun handle(text: String) {
        NabaState.update(NabaState.Mode.THINKING, text, "Understanding…")
        val l = LangDetect.detect(text)
        val fu = followUp
        if (fu != null) { followUp = null; fu(text, l); return }
        run(CommandParser.parse(text, CommandParser.loadApps(this)), l)
    }

    private fun run(c: Command, l: Lang) {
        when (c) {
            Command.Unknown -> reply(tr(l, "Sorry, I didn't understand. Please try again.", "माफ़ कीजिए, मैं समझ नहीं पाई। फिर से कहिए।", "দুঃখিত, বুজি নাপালোঁ। আকৌ কওক।"), l)
            Command.Cancel -> reply(tr(l, "Okay.", "ठीक है।", "ঠিক আছে।"), l)
            is Command.Search -> if (c.query.isBlank()) {
                followUp = { t, l2 -> run(c.copy(query = t.trim()), l2) }
                ask(tr(l, "What should I search for?", "क्या खोजूँ?", "কি সন্ধান কৰিম?"), l)
            } else reply(exec.execute(c, l), l)
            is Command.Call -> callFlow(c, l)
            is Command.Message -> messageFlow(c, l)
            is Command.Tap -> if (CommandParser.isSensitive(c)) {
                confirm(tr(l, "You asked me to press “${c.label}”. Are you sure?", "आप “${c.label}” दबाने को कह रहे हैं। पक्का?", "আপুনি “${c.label}” টিপিবলৈ কৈছে। নিশ্চিত নে?"), l) { l2 -> reply(exec.execute(c, l2), l2) }
            } else reply(exec.execute(c, l), l)
            else -> reply(exec.execute(c, l), l)
        }
    }

    private fun callFlow(c: Command.Call, l: Lang) {
        if (c.target.isBlank()) {
            followUp = { t, l2 -> callFlow(c.copy(target = t.trim()), l2) }
            ask(tr(l, "Whom should I call?", "किसे कॉल करूँ?", "কাক কল কৰিম?"), l); return
        }
        confirm(tr(l, "Call ${c.target}?", "${c.target} को कॉल करूँ?", "${c.target} ক কল কৰিম নে?"), l) { l2 -> reply(exec.call(c.target, l2), l2) }
    }

    private fun messageFlow(c: Command.Message, l: Lang) {
        if (c.recipient.isBlank()) {
            followUp = { t, l2 -> messageFlow(c.copy(recipient = t.trim()), l2) }
            ask(tr(l, "Who should I message?", "किसे मैसेज भेजूँ?", "কাক বাৰ্তা পঠিয়াম?"), l); return
        }
        if (c.body.isBlank()) {
            followUp = { t, l2 -> messageFlow(c.copy(body = t.trim()), l2) }
            ask(tr(l, "What should I write?", "क्या लिखूँ?", "কি লিখিম?"), l); return
        }
        confirm(tr(l, "Message to ${c.recipient}: “${c.body}”. Shall I go ahead?", "${c.recipient} को मैसेज: “${c.body}”। आगे बढ़ूँ?", "${c.recipient} লৈ বাৰ্তা: “${c.body}”। আগবাঢ়িম নে?"), l) { l2 ->
            reply(exec.message(c, l2), l2)
        }
    }

    private fun confirm(question: String, l: Lang, onYes: (Lang) -> Unit) {
        followUp = { t, l2 ->
            if (YesNo.yes(t)) onYes(l2) else reply(tr(l2, "Okay, cancelled.", "ठीक है, रद्द किया।", "ঠিক আছে, বাতিল কৰিলোঁ।"), l2)
        }
        ask(question, l)
    }

    /** Speak, then listen again for the answer. */
    private fun ask(q: String, l: Lang) {
        NabaState.update(NabaState.Mode.SPEAKING, action = q)
        voice.speak(q, l) { beginListening() }
    }

    /** Speak, then go back to waiting for "Hi Naba". */
    private fun reply(text: String, l: Lang) {
        NabaState.update(NabaState.Mode.SPEAKING, action = text)
        voice.speak(text, l) { finish() }
    }

    private fun finish() {
        busy = false
        followUp = null
        asr?.destroy(); asr = null
        NabaState.update(live = "")
        startWake()
    }
}
