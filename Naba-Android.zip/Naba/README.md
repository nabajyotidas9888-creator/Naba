# Naba — free Android voice assistant (Assamese · Hindi · English)

## Build (5 steps)
1. Install Android Studio (Hedgehog or newer). Open this folder; accept the Gradle 8.2 prompt.
2. Download the free Indian-English wake-word model **vosk-model-small-en-in-0.4** from https://alphacephei.com/vosk/models
3. Unzip it and rename the folder to `model-en-in`. Put it at `app/src/main/assets/model-en-in/` (it must contain `am`, `conf`, `graph`, `ivector`).
4. Run on a real phone (Android 8+). Emulators have poor microphones.
5. In the app: allow Microphone, then turn on Accessibility → Naba. Optional: notification access, contacts/phone.

## How it works
- `NabaService` (foreground, microphone type): Vosk listens offline for "Hi / Hii (me / I am) Naba". Nothing is recorded or sent.
- After the wake phrase it greets you, then Android's SpeechRecognizer (Google; as-IN / hi-IN / en-IN) hears the command.
- `CommandParser` understands Assamese/Hindi/English (native script and romanized, mixed) → `ActionExecutor` acts → `NabaVoice` replies in your language.
- `NabaAccessibilityService`: Home/Back/Recents, scroll, tap, and the floating draggable mic bubble (live text + current action).
- Call, message, and pressing buttons named Delete/Pay/Send/etc. always ask "yes/no" first. Messages open pre-written; you press Send. Naba never enters PINs.

## Known limits (Android, not bugs)
- Wake word: if the model has no word like "naba", Naba falls back to free-form matching (works, uses more battery). Test it; tune `WAKE` in `NabaService.kt`.
- Android 14+ refuses to start a microphone service from the background (e.g. at boot). Open Naba once after a reboot.
- Battery/OEM killers (Xiaomi, Realme, Vivo…): set Naba to "Unrestricted/No restrictions" and allow autostart.
- Voice: uses your phone's installed text-to-speech voices. Google TTS has no Assamese voice, so Assamese replies use Bengali (bn-IN) or English. Pick the softest female en-IN/hi-IN voice in *Change Naba's voice*. Pitch is raised in code (`NabaVoice.kt`).
- Assamese recognition quality depends on Google's `as-IN` model. If Auto misdetects, choose a fixed command language in the app.
- Language detection is keyword based; extend the word lists in `Commands.kt` and `Lang.kt`.
- Not compiled/tested by the author on a device. Expect to fix small build errors.
